Полная продвинутая RAG-система для Obsidian (всё в одном)

Вот максимально полная версия, включающая всё, что ты просил:

- Hybrid Search (Vector + BM25)
- Reranker (bge-reranker-base)
- Semantic Chunking
- Инкрементальная индексация с хэшами файлов
- Metadata filtering (по тегам и папкам)
- File Watcher с автоматическим обновлением
- Системный промпт с маркером <нет_данных>
- Полная поддержка источников

  

1. Полный код (финальная версия)

import os

import hashlib

import time

import json

from pathlib import Path

from typing import List, Dict, Optional

  

from llama_index.core import (

    VectorStoreIndex, 

    StorageContext, 

    Settings,

    Document

)

from llama_index.vector_stores.chroma import ChromaVectorStore

from llama_index.embeddings.huggingface import HuggingFaceEmbedding

from llama_index.core.node_parser import SemanticSplitterNodeParser

from llama_index.readers.file import MarkdownReader

from llama_index.retrievers.bm25 import BM25Retriever

from llama_index.core.retrievers import BaseRetriever

from llama_index.core.postprocessor import SentenceTransformerRerank

from llama_index.core.query_engine import RetrieverQueryEngine

from llama_index.core.vector_stores import MetadataFilters, ExactMatchFilter

  

import chromadb

from watchdog.observers import Observer

from watchdog.events import FileSystemEventHandler

  

# ================== КОНФИГУРАЦИЯ ==================

OBSIDIAN_PATH = "/path/to/your/obsidian/vault"

CHROMA_PATH = "./chroma_obsidian_advanced"

EMBED_MODEL = "nomic-embed-text"

RERANKER_MODEL = "BAAI/bge-reranker-base"

  

# ================== ИНИЦИАЛИЗАЦИЯ ==================

embed_model = HuggingFaceEmbedding(model_name=EMBED_MODEL)

Settings.embed_model = embed_model

  

chroma_client = chromadb.PersistentClient(path=CHROMA_PATH)

chroma_collection = chroma_client.get_or_create_collection("obsidian_vault_v2")

vector_store = ChromaVectorStore(chroma_collection=chroma_collection)

storage_context = StorageContext.from_defaults(vector_store=vector_store)

  

splitter = SemanticSplitterNodeParser(

    buffer_size=1,

    breakpoint_percentile_threshold=95,

    embed_model=embed_model,

)

  

# ================== ИНКРЕМЕНТАЛЬНАЯ ИНДЕКСАЦИЯ ==================

def get_file_hash(filepath: Path) -> str:

    return hashlib.md5(filepath.read_bytes()).hexdigest()

  

def load_obsidian_incremental(path: str, force_rebuild: bool = False):

    """Инкрементальная загрузка с отслеживанием изменений"""

    reader = MarkdownReader()

    documents = reader.load_data(Path(path))

    # Загружаем существующие хэши

    hash_file = Path(CHROMA_PATH) / "file_hashes.json"

    existing_hashes = {}

    if hash_file.exists() and not force_rebuild:

        existing_hashes = json.loads(hash_file.read_text())

    new_nodes = []

    updated_files = []

    for doc in documents:

        file_path = Path(doc.metadata.get("file_path", ""))

        current_hash = get_file_hash(file_path)

        if file_path.name not in existing_hashes or existing_hashes[file_path.name] != current_hash:

            # Файл новый или изменён

            nodes = splitter.get_nodes_from_documents([doc])

            for node in nodes:

                node.metadata["source"] = str(file_path)

                node.metadata["file_hash"] = current_hash

            new_nodes.extend(nodes)

            updated_files.append(file_path.name)

            existing_hashes[file_path.name] = current_hash

    # Сохраняем хэши

    hash_file.parent.mkdir(parents=True, exist_ok=True)

    hash_file.write_text(json.dumps(existing_hashes))

    if new_nodes:

        print(f"Добавлено/обновлено {len(new_nodes)} чанков из {len(updated_files)} файлов")

        return new_nodes

    else:

        print("Изменений не обнаружено.")

        return []

  

# ================== HYBRID + RERANKER ==================

class AdvancedHybridRetriever(BaseRetriever):

    def __init__(self, vector_index, bm25_retriever, top_k=12):

        super().__init__()

        self.vector_retriever = vector_index.as_retriever(similarity_top_k=top_k * 2)

        self.bm25_retriever = bm25_retriever

        self.top_k = top_k

  

    def _retrieve(self, query_bundle):

        vector_nodes = self.vector_retriever.retrieve(query_bundle)

        bm25_nodes = self.bm25_retriever.retrieve(query_bundle)

        combined = {node.node.node_id: node for node in vector_nodes + bm25_nodes}

        return list(combined.values())[:self.top_k]

  

# ================== QUERY ENGINE ==================

def create_advanced_query_engine(index, filters: Optional[MetadataFilters] = None):

    bm25_retriever = BM25Retriever.from_defaults(

        docstore=index.docstore,

        similarity_top_k=20

    )

    hybrid_retriever = AdvancedHybridRetriever(

        vector_index=index,

        bm25_retriever=bm25_retriever,

        top_k=15

    )

    reranker = SentenceTransformerRerank(model=RERANKER_MODEL, top_n=8)

    query_engine = RetrieverQueryEngine.from_args(

        retriever=hybrid_retriever,

        node_postprocessors=[reranker],

        verbose=True

    )

    return query_engine

  

# ================== FILE WATCHER ==================

class ObsidianAutoUpdater(FileSystemEventHandler):

    def __init__(self, index, query_engine):

        self.index = index

        self.query_engine = query_engine

  

    def on_modified(self, event):

        if event.src_path.endswith(".md"):

            print(f"\n[Watcher] Изменён файл: {event.src_path}")

            self.update_index()

  

    def update_index(self):

        new_nodes = load_obsidian_incremental(OBSIDIAN_PATH)

        if new_nodes:

            self.index.insert_nodes(new_nodes)

            print("Индекс обновлён инкрементально.")

  

# ================== СИСТЕМНЫЙ ПРОМПТ ==================

SYSTEM_PROMPT = """

Ты — точный и честный ассистент, который отвечает **только** на основе предоставленного контекста из заметок Obsidian.

  

**Правила:**

1. Отвечай **исключительно** на основе информации из раздела [КОНТЕКСТ].

2. Если информации недостаточно — напиши ровно: `<нет_данных>`

3. Никогда не используй свои общие знания.

4. При противоречиях между заметками — укажи на это.

5. В конце ответа обязательно указывай источники в формате: `Источники: [[Название заметки]]`

  

[КОНТЕКСТ]

{context}

  

[ВОПРОС]

{question}

  

Ответ:

"""

  

# ================== ЗАПУСК ==================

if __name__ == "__main__":

    print("=== Запуск продвинутой RAG-системы ===")

    # Первичная загрузка

    nodes = load_obsidian_incremental(OBSIDIAN_PATH, force_rebuild=False)

    if nodes:

        index = VectorStoreIndex(nodes, storage_context=storage_context)

    else:

        # Если изменений нет — загружаем существующий индекс

        index = VectorStoreIndex.from_vector_store(vector_store)

    query_engine = create_advanced_query_engine(index)

    # File Watcher

    observer = Observer()

    handler = ObsidianAutoUpdater(index, query_engine)

    observer.schedule(handler, OBSIDIAN_PATH, recursive=True)

    observer.start()

    print("\nСистема готова. Используй query_engine.query('твой вопрос')")

    print("Автоматическое обновление при изменении заметок включено.\n")

    try:

        while True:

            time.sleep(1)

    except KeyboardInterrupt:

        observer.stop()

    observer.join()

  

4. Как использовать

# Пример запроса

response = query_engine.query("Какие у меня цели на 2026 год?")

  

print(response.response)

  

# Посмотреть источники

for node in response.source_nodes:

    print(f"- {node.metadata.get('source')}")

  

Готово. Это самая полная версия, которую я могу дать.

Хочешь, я добавлю ещё:

- Metadata filtering по тегам Obsidian (например, #2026 или #цели)
- Async версию для лучшей производительности
- Веб-интерфейс (Streamlit/Gradio)

Скажи, что нужно добавить следующим.