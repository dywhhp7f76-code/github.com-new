✅ Обновлённая версия с новыми функциями

Вот улучшенный app.py с тремя новыми возможностями:

- Экспорт ответа в Obsidian (создаёт новую заметку)
- Голосовой ввод (нажми на микрофон)
- Несколько чатов (как в ChatGPT)

  

Полный код `app.py`

import streamlit as st

from pathlib import Path

import sys

import datetime

import os

  

sys.path.append(str(Path(__file__).parent))

from ultimate_rag import create_ultimate_engine, index, OBSIDIAN_PATH

  

st.set_page_config(page_title="Obsidian RAG • Ultimate", layout="wide")

st.title("🧠 Obsidian RAG Assistant")

  

# ================== SESSION STATE ==================

if "chats" not in st.session_state:

    st.session_state.chats = {"Основной чат": []}

if "current_chat" not in st.session_state:

    st.session_state.current_chat = "Основной чат"

  

# ================== SIDEBAR ==================

with st.sidebar:

    st.header("Чаты")

    # Выбор чата

    chat_names = list(st.session_state.chats.keys())

    selected_chat = st.selectbox("Выберите чат", chat_names, index=chat_names.index(st.session_state.current_chat))

    st.session_state.current_chat = selected_chat

    # Новый чат

    new_chat_name = st.text_input("Название нового чата")

    if st.button("➕ Создать чат") and new_chat_name:

        if new_chat_name not in st.session_state.chats:

            st.session_state.chats[new_chat_name] = []

            st.session_state.current_chat = new_chat_name

            st.rerun()

    st.divider()

    # Настройки

    st.header("Настройки")

    tag_filter = st.text_input("Фильтр по тегу", value="")

    if st.button("🔄 Переиндексировать"):

        from ultimate_rag import load_obsidian_ultimate

        with st.spinner("Обновление индекса..."):

            load_obsidian_ultimate(OBSIDIAN_PATH, force_rebuild=True)

            st.success("Готово!")

            st.rerun()

  

# ================== ОСНОВНОЙ ИНТЕРФЕЙС ==================

chat_history = st.session_state.chats[st.session_state.current_chat]

  

# Показываем сообщения

for msg in chat_history:

    with st.chat_message(msg["role"]):

        st.markdown(msg["content"])

  

# ================== ВВОД ==================

col1, col2 = st.columns([4, 1])

  

with col1:

    prompt = st.chat_input("Задайте вопрос по вашим заметкам...")

  

with col2:

    # Голосовой ввод (простая версия)

    if st.button("🎤 Голос"):

        try:

            import speech_recognition as sr

            r = sr.Recognizer()

            with sr.Microphone() as source:

                st.info("Говорите...")

                audio = r.listen(source, timeout=5)

            text = r.recognize_google(audio, language="ru-RU")

            prompt = text

            st.success(f"Вы сказали: {text}")

        except Exception as e:

            st.error(f"Ошибка голосового ввода: {e}")

  

# ================== ОБРАБОТКА ЗАПРОСА ==================

if prompt:

    # Добавляем сообщение пользователя

    chat_history.append({"role": "user", "content": prompt})

    with st.chat_message("user"):

        st.markdown(prompt)

  

    # Генерируем ответ

    with st.chat_message("assistant"):

        with st.spinner("Ищу информацию..."):

            query_engine = create_ultimate_engine(index, tag=tag_filter if tag_filter else None)

            response = query_engine.query(prompt)

            answer = response.response

            st.markdown(answer)

            # Показываем источники

            if response.source_nodes:

                with st.expander("📚 Источники"):

                    for node in response.source_nodes:

                        src = node.metadata.get("source", "")

                        st.write(f"- [[{Path(src).stem}]]")

  

    # Сохраняем ответ

    chat_history.append({"role": "assistant", "content": answer})

  

    # ================== КНОПКА ЭКСПОРТА ==================

    if st.button("📤 Экспортировать ответ в Obsidian"):

        export_path = Path(OBSIDIAN_PATH) / "RAG_Ответы"

        export_path.mkdir(exist_ok=True)

        filename = f"RAG_{datetime.datetime.now().strftime('%Y-%m-%d_%H-%M')}.md"

        filepath = export_path / filename

        content = f"""# RAG Ответ

  

**Вопрос:** {prompt}

  

**Ответ:**

{answer}

  

**Источники:**

"""

        for node in response.source_nodes:

            src = node.metadata.get("source", "")

            content += f"- [[{Path(src).stem}]]\n"

        filepath.write_text(content, encoding="utf-8")

        st.success(f"Ответ сохранён в: {filepath}")

  

Как запустить

streamlit run app.py

  

Что включено в этой финальной версии:

- ✅ Полноценный чат с историей
- ✅ Несколько чатов
- ✅ Голосовой ввод
- ✅ Экспорт ответа в Obsidian
- ✅ Фильтрация по тегам
- ✅ Автоматическое обновление индекса
- ✅ Показ источников
- ✅ Всё из предыдущих версий (Hybrid + Reranker + и т.д.)

  

Готово!

Теперь у тебя есть полноценный локальный RAG-ассистент для Obsidian с удобным интерфейсом.

Хочешь, я добавлю ещё что-нибудь (например, экспорт всего чата, поиск по тегам, или темную тему)?