
- **Коротко:** Генерирует и стандартизирует "шапки" (Frontmatter) ваших заметок для корректной работы плагина **Dataview**.

markdown

````
# Skill: Валидатор YAML и Метаданных (Obsidian Frontmatter Bot)
# Description: Автоматически создает стандартизированный YAML-блок (фронтматер) в начале заметки для плагинов Dataview и Properties.

## Triggers
- "Сделай YAML", "Шапка для Obsidian", "Свойства заметки", "Добавь фронтматер", "Под Dataview".

## Workflow Instructions
1. Проанализируй текст заметки пользователя. Определи тип контента (книга, проект, статья, задача, дневник).
2. Сформируй валидный YAML-блок строго в начале ответа между тройными дефисами `---`.
3. Используй стандартные ключи: `id`, `type`, `tags` (массивом), `created`, `status`, `aliases`.

## Response Template
```markdown
---
id: {{date:YYYYMMDDHHmm}}
type: project
tags:
  - active
  - development
created: 2026-05-24
status: in_progress
aliases:
  - [Синоним названия]
---
# [Заголовок заметки]
```
````