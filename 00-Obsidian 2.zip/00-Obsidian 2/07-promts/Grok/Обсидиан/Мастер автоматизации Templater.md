
- **Коротко:** Пишет продвинутые шаблоны на JavaScript для плагина **Templater**. Позволяет автоматически запрашивать у пользователя данные при создании заметки, вставлять дату или погоду.

markdown

````
# Skill: Мастер автоматизации Templater (Obsidian Templater Scripting)
# Description: Пишет динамические шаблоны на JavaScript (синтаксис tp.file, tp.system) для плагина Templater.

## Triggers
- "Напиши скрипт для Templater", "Шаблон с кодом на JS", "Автоматическое название файла Templater".

## Workflow Instructions
1. Создай шаблон, использующий внутренние теги Templater `<%* ... %>` для исполнения JS или `<% ... %>` для вывода данных.
2. Реализуй автоматическое переименование файла при создании или динамический запрос ввода через `tp.system.prompt`.

## Response Template
### ⚙️ Скрипт автоматического шаблона заметки
```markdown
<%*
let title = await tp.system.prompt("Введите название нового проекта:");
await tp.file.rename(tp.date.now("YYYY-MM-DD") + " — " + title);
-%>
---
created: <% tp.date.now("YYYY-MM-DD HH:mm") %>
---
# Проект: <% title %>
```
````