✅ Обновлённый app.py с полной интеграцией мониторинга

Вот финальная версия app.py, которая использует monitoring.py:

import streamlit as st

from pathlib import Path

import sys

import datetime

  

sys.path.append(str(Path(__file__).parent))

  

from ultimate_rag import create_ultimate_engine, index, OBSIDIAN_PATH

from monitoring import monitor_request, is_attack_attempt, get_metrics, send_telegram_alert

  

st.set_page_config(page_title="Obsidian RAG • Ultimate", layout="wide")

st.title("🧠 Obsidian RAG Assistant + Security")

  

# ================== SIDEBAR ==================

with st.sidebar:

    st.header("Чаты")

    if "chats" not in st.session_state:

        st.session_state.chats = {"Основной чат": []}

    if "current_chat" not in st.session_state:

        st.session_state.current_chat = "Основной чат"

    chat_names = list(st.session_state.chats.keys())

    st.session_state.current_chat = st.selectbox(

        "Выберите чат", 

        chat_names, 

        index=chat_names.index(st.session_state.current_chat)

    )

    new_chat = st.text_input("Новый чат")

    if st.button("➕ Создать") and new_chat:

        if new_chat not in st.session_state.chats:

            st.session_state.chats[new_chat] = []

            st.session_state.current_chat = new_chat

            st.rerun()

    st.divider()

    st.header("Безопасность")

    tag_filter = st.text_input("Фильтр по тегу", value="")

    if st.button("🔄 Переиндексировать"):

        from ultimate_rag import load_obsidian_ultimate

        with st.spinner("Обновление..."):

            load_obsidian_ultimate(OBSIDIAN_PATH, force_rebuild=True)

            st.success("Готово!")

            st.rerun()

    # Метрики в сайдбаре

    metrics = get_metrics()

    st.metric("Всего запросов", metrics.get("total_requests", 0))

    st.metric("Заблокировано", metrics.get("blocked", 0))

  

# ================== ЧАТ ==================

chat_history = st.session_state.chats[st.session_state.current_chat]

  

for msg in chat_history:

    with st.chat_message(msg["role"]):

        st.markdown(msg["content"])

  

# ================== ВВОД ==================

prompt = st.chat_input("Задайте вопрос...")

  

if prompt:

    chat_history.append({"role": "user", "content": prompt})

    with st.chat_message("user"):

        st.markdown(prompt)

  

    with st.chat_message("assistant"):

        with st.spinner("Анализирую запрос..."):

            # Проверка на атаку

            if is_attack_attempt(prompt):

                answer = "<нет_данных> Запрос выглядит подозрительно. Доступ ограничен."

                st.warning("⚠️ Обнаружена попытка обхода защиты!")

                send_telegram_alert(f"Попытка атаки!\nЗапрос: {prompt[:200]}", critical=True)

            else:

                query_engine = create_ultimate_engine(index, tag=tag_filter if tag_filter else None)

                response = query_engine.query(prompt)

                answer = response.response

  

            st.markdown(answer)

  

            # Показываем источники

            if hasattr(response, 'source_nodes') and response.source_nodes:

                with st.expander("📚 Источники"):

                    for node in response.source_nodes:

                        src = node.metadata.get("source", "")

                        st.write(f"- [[{Path(src).stem}]]")

  

    # Сохраняем в историю

    chat_history.append({"role": "assistant", "content": answer})

  

    # ================== МОНИТОРИНГ ==================

    is_blocked = is_attack_attempt(prompt)

    is_no_data = "<нет_данных>" in answer

    monitor_request(

        query=prompt,

        response=answer,

        is_blocked=is_blocked,

        is_no_data=is_no_data

    )

  

# ================== ЭКСПОРТ ==================

if st.button("📤 Экспортировать последний ответ в Obsidian"):

    if chat_history:

        last_response = chat_history[-1]["content"]

        export_path = Path(OBSIDIAN_PATH) / "RAG_Ответы"

        export_path.mkdir(exist_ok=True)

        filename = f"RAG_{datetime.datetime.now().strftime('%Y-%m-%d_%H-%M')}.md"

        filepath = export_path / filename

        content = f"""# RAG Ответ

  

**Вопрос:** {chat_history[-2]['content'] if len(chat_history) >= 2 else 'N/A'}

  

**Ответ:**

{last_response}

  

**Дата:** {datetime.datetime.now().strftime('%Y-%m-%d %H:%M')}

"""

        filepath.write_text(content, encoding="utf-8")

        st.success(f"Сохранено: {filepath}")

  

Как запустить

1. Убедись, что у тебя есть файлы:

- ultimate_rag.py
- monitoring.py
- app.py (код выше)

3. Запусти:

streamlit run app.py

  

Готово!

Теперь у тебя есть полностью интегрированная система с:

- Чатом
- Мониторингом
- Алертингом в Telegram
- Экспортом в Obsidian
- Автоматическим обновлением индекса

Хочешь, я добавлю ещё что-нибудь (например, экспорт всего чата или анализ галлюцинаций)?