---
tags: [крепость, код, rag, chroma, ядро]
date: 2026-06
version: 3.0
status: готово
depends_on: smart_cache.py (EmbeddingProvider через DI), document_ingestion.py (VaultWatcher, quarantine-флаги)
replaces: все версии ultimate_rag «финальная 2.x» — старые в archive/
---

# Ultimate RAG v3.0 — прямой Chroma, без LlamaIndex

## Что изменилось радикально

- **Убран LlamaIndex целиком.** Прямой `chromadb` + `sentence-transformers`.
- **Единый `EmbeddingProvider`** с Cache/Memory (`intfloat/multilingual-e5-base`).
- **Инкрементальная индексация** delete+add — без дублей в Chroma.
- **RAG не кэширует и не знает про monitoring** — это делает слой выше.

## Где класть
```bash
mkdir -p krepost/rag
touch krepost/rag/__init__.py
# → krepost/rag/ultimate_rag.py
```

## Зависимости
```bash
pip install chromadb sentence-transformers rank-bm25 pyyaml numpy loguru pydantic
# НЕТ llama-index, НЕТ aiohttp — стек унифицирован с Cache/Memory
```
**[НЕПОДТВЕРЖДЕНО]** `bge-reranker-v2-m3` ~600 МБ при первом запуске. `multilingual-e5-base` уже скачан Cache/Memory.

## Код

```python
"""
krepost/rag/ultimate_rag.py
Ultimate RAG v3.0 — прямой ChromaDB, общий EmbeddingProvider, hybrid + rerank.

Без LlamaIndex. Использует тот же EmbeddingProvider, что Cache и Memory
(intfloat/multilingual-e5-base) — векторы совместимы, L2-кэш работает.

RAG только ищет и отдаёт RagResult. Кэширование и monitoring — на уровень выше.
"""

from __future__ import annotations

import asyncio
import hashlib
import json
import math
import re
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Callable, Dict, List, Optional, Protocol

import numpy as np
import yaml
from loguru import logger
from pydantic import BaseModel, Field


# ═══════════════════════════════════════════════════════════════════════════
# init
# ═══════════════════════════════════════════════════════════════════════════

def init_logging(log_dir: Path = Path("data/logs")) -> None:
    log_dir.mkdir(parents=True, exist_ok=True)
    logger.add(log_dir / "rag.log", rotation="10 MB", level="INFO", enqueue=True)


# ═══════════════════════════════════════════════════════════════════════════
# EmbeddingProvider Protocol (тот же, что в Cache/Memory; передаётся через DI)
# ═══════════════════════════════════════════════════════════════════════════

class EmbeddingProviderProtocol(Protocol):
    model_name: str
    dim: int
    def encode_query(self, text: str) -> np.ndarray: ...
    def encode_passage(self, text: str) -> np.ndarray: ...


# ═══════════════════════════════════════════════════════════════════════════
# Модели результата
# ═══════════════════════════════════════════════════════════════════════════

class RetrievedChunk(BaseModel):
    chunk_id: str
    text: str
    source: str
    tags: List[str] = Field(default_factory=list)
    quarantine: bool = False
    score: float                      # rerank score (sigmoid 0..1)


class RagResult(BaseModel):
    query: str
    chunks: List[RetrievedChunk]
    rag_score: float                  # релевантность топ-чанка (для Triggers/Учителя)

    @property
    def context(self) -> str:
        """Склейка чанков для подачи Учителю."""
        return "\n\n---\n\n".join(c.text for c in self.chunks)


# ═══════════════════════════════════════════════════════════════════════════
# Frontmatter + chunking
# ═══════════════════════════════════════════════════════════════════════════

_INLINE_TAG_RE = re.compile(r"(?:^|\s)#([\w/\-а-яА-ЯёЁ]+)")
_HEADING_RE = re.compile(r"^#{1,6}\s")


def parse_frontmatter(text: str) -> tuple[dict, str]:
    """Возвращает (yaml_meta, body)."""
    if text.startswith("---"):
        end = text.find("\n---", 3)
        if end != -1:
            raw = text[3:end].strip()
            body = text[end + 4:].lstrip("\n")
            try:
                meta = yaml.safe_load(raw) or {}
                if not isinstance(meta, dict):
                    meta = {}
            except Exception:
                meta = {}
            return meta, body
    return {}, text


def extract_tags(meta: dict, body: str) -> List[str]:
    tags: List[str] = []
    fm_tags = meta.get("tags", [])
    if isinstance(fm_tags, list):
        tags.extend(str(t) for t in fm_tags)
    elif isinstance(fm_tags, str):
        tags.append(fm_tags)
    tags.extend(_INLINE_TAG_RE.findall(body))
    # уникализируем, сохраняем порядок
    seen, out = set(), []
    for t in tags:
        t = t.strip().lower()
        if t and t not in seen:
            seen.add(t)
            out.append(t)
    return out[:20]


def chunk_markdown(body: str, max_chars: int = 1500, overlap: int = 200) -> List[str]:
    """Heading-aware нарезка: режем по заголовкам, длинные секции — окном с перекрытием."""
    lines = body.split("\n")
    sections: List[List[str]] = []
    current: List[str] = []
    for line in lines:
        if _HEADING_RE.match(line) and current:
            sections.append(current)
            current = [line]
        else:
            current.append(line)
    if current:
        sections.append(current)

    chunks: List[str] = []
    for sec_lines in sections:
        sec = "\n".join(sec_lines).strip()
        if not sec:
            continue
        if len(sec) <= max_chars:
            chunks.append(sec)
        else:
            start = 0
            step = max(1, max_chars - overlap)
            while start < len(sec):
                chunks.append(sec[start:start + max_chars])
                start += step
    return chunks


# ═══════════════════════════════════════════════════════════════════════════
# Утилиты
# ═══════════════════════════════════════════════════════════════════════════

SKIP_DIR_PARTS = {".git", ".obsidian", "node_modules", "__pycache__", ".venv"}
_TOKEN_RE = re.compile(r"\w+", re.UNICODE)


def _sigmoid(x: float) -> float:
    return 1.0 / (1.0 + math.exp(-x))


def _tokenize(text: str) -> List[str]:
    return _TOKEN_RE.findall(text.lower())


def _file_id(source: str) -> str:
    return hashlib.sha256(source.encode("utf-8")).hexdigest()[:16]


def _read_text(path: Path) -> str:
    raw = path.read_bytes()
    for enc in ("utf-8-sig", "utf-8", "windows-1251", "cp1252"):
        try:
            return raw.decode(enc)
        except UnicodeDecodeError:
            continue
    return raw.decode("utf-8", errors="replace")


def _atomic_write(path: Path, content: str) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    tmp = path.with_suffix(path.suffix + ".tmp")
    tmp.write_text(content, encoding="utf-8")
    tmp.replace(path)


def _streaming_hash(path: Path) -> str:
    h = hashlib.sha256()
    with open(path, "rb") as f:
        for block in iter(lambda: f.read(8192), b""):
            h.update(block)
    return h.hexdigest()


# ═══════════════════════════════════════════════════════════════════════════
# UltimateRAG
# ═══════════════════════════════════════════════════════════════════════════

class UltimateRAG:
    """
    Hybrid RAG (vector + BM25 + rerank) на прямом ChromaDB.

    Использование:
        provider = EmbeddingProvider()           # из smart_cache, общий на систему
        rag = UltimateRAG(provider, vault_dir=Path("vault"))
        rag.index_directory(Path("vault"))

        result = await rag.search("что такое RAG?", top_k=8)
        context = result.context
        score = result.rag_score                 # для Triggers/Учителя

        # Подписка на изменения заметок (VaultWatcher из document_ingestion):
        def on_note_changed(path: str):
            rag.reindex_file(Path(path))
            cache.invalidate_by_note(path)        # кэш отдельно
        vault_watcher = VaultWatcher(Path("vault"), on_note_changed=on_note_changed)
    """

    RRF_K = 60                    # константа reciprocal rank fusion
    DEFAULT_RERANKER = "BAAI/bge-reranker-v2-m3"

    def __init__(
        self,
        provider: EmbeddingProviderProtocol,
        vault_dir: Path = Path("vault"),
        chroma_path: Path = Path("data/chroma_rag"),
        collection_name: str = "krepost_rag",
        hashes_path: Path = Path("data/rag_hashes.json"),
        reranker_model: str = DEFAULT_RERANKER,
        max_chars: int = 1500,
        overlap: int = 200,
        candidate_k: int = 30,
        on_event: Optional[Callable[[Any], None]] = None,
    ):
        self.provider = provider
        self.vault_dir = vault_dir.resolve()
        self.hashes_path = hashes_path
        self.reranker_model = reranker_model
        self.max_chars = max_chars
        self.overlap = overlap
        self.candidate_k = candidate_k
        self.on_event = on_event

        # Chroma (прямой клиент)
        import chromadb
        chroma_path.parent.mkdir(parents=True, exist_ok=True)
        self._client = chromadb.PersistentClient(path=str(chroma_path))
        self._collection = self._client.get_or_create_collection(
            name=collection_name,
            metadata={"hnsw:space": "cosine", "embedding_model": provider.model_name},
        )

        self._hashes: Dict[str, str] = self._load_hashes()

        # Реранкер — ленивая загрузка
        self._reranker = None

        # BM25 — строится из Chroma, помечается dirty при изменениях
        self._bm25 = None
        self._bm25_ids: List[str] = []
        self._bm25_docs: List[str] = []
        self._bm25_metas: List[dict] = []
        self._bm25_dirty = True

    # ── Hashes ────────────────────────────────────────────────────────────

    def _load_hashes(self) -> Dict[str, str]:
        if not self.hashes_path.exists():
            return {}
        try:
            return json.loads(self.hashes_path.read_text(encoding="utf-8"))
        except Exception:
            logger.exception("RAG hashes load failed — starting fresh")
            return {}

    def _save_hashes(self) -> None:
        try:
            _atomic_write(self.hashes_path,
                          json.dumps(self._hashes, ensure_ascii=False, indent=2))
        except OSError:
            logger.exception("RAG hashes save failed")

    def _rel_key(self, path: Path) -> str:
        try:
            return str(path.resolve().relative_to(self.vault_dir))
        except ValueError:
            return path.name

    # ── Lazy reranker ───────────────────────────────────────────────────────

    def _get_reranker(self):
        if self._reranker is None:
            from sentence_transformers import CrossEncoder
            logger.info(f"Loading reranker {self.reranker_model}...")
            self._reranker = CrossEncoder(self.reranker_model)
        return self._reranker

    # ── Индексация ──────────────────────────────────────────────────────────

    def index_file(self, path: Path, force: bool = False) -> int:
        """Проиндексировать один файл (delete+add). Возвращает число чанков."""
        if path.suffix.lower() != ".md":
            return 0
        if not path.exists():
            return 0

        source = str(path.resolve())
        rel = self._rel_key(path)
        file_hash = _streaming_hash(path)

        if not force and self._hashes.get(rel) == file_hash:
            return 0  # не изменился

        text = _read_text(path)
        meta_fm, body = parse_frontmatter(text)
        tags = extract_tags(meta_fm, body)
        quarantine = bool(meta_fm.get("quarantine", False))
        chunks = chunk_markdown(body, self.max_chars, self.overlap)

        # delete старые чанки этого файла (нет дублей)
        try:
            self._collection.delete(where={"source": source})
        except Exception:
            logger.exception(f"Chroma delete failed for {source}")

        if not chunks:
            self._hashes[rel] = file_hash
            self._save_hashes()
            self._bm25_dirty = True
            return 0

        fid = _file_id(source)
        ids = [f"{fid}_{i}" for i in range(len(chunks))]
        embeddings = [self.provider.encode_passage(c).tolist() for c in chunks]
        tags_str = ",".join(tags)
        metadatas = [
            {
                "source": source,
                "rel": rel,
                "chunk_index": i,
                "file_hash": file_hash,
                "tags": tags_str,
                "quarantine": quarantine,
            }
            for i in range(len(chunks))
        ]

        try:
            self._collection.add(
                ids=ids, embeddings=embeddings, documents=chunks, metadatas=metadatas,
            )
        except Exception:
            logger.exception(f"Chroma add failed for {source}")
            return 0

        self._hashes[rel] = file_hash
        self._save_hashes()
        self._bm25_dirty = True
        logger.info(f"Indexed {rel} | {len(chunks)} chunks | quarantine={quarantine}")
        return len(chunks)

    def reindex_file(self, path: Path) -> int:
        """Принудительная переиндексация (для VaultWatcher)."""
        return self.index_file(path, force=True)

    def delete_file(self, path: Path) -> None:
        source = str(path.resolve())
        try:
            self._collection.delete(where={"source": source})
        except Exception:
            logger.exception(f"Chroma delete failed for {source}")
        self._hashes.pop(self._rel_key(path), None)
        self._save_hashes()
        self._bm25_dirty = True

    def index_directory(self, directory: Path, force_rebuild: bool = False) -> int:
        """Batch-индексация vault. force_rebuild — полная перестройка коллекции."""
        if force_rebuild:
            try:
                name = self._collection.name
                self._client.delete_collection(name)
                import chromadb  # noqa
                self._collection = self._client.get_or_create_collection(
                    name=name,
                    metadata={"hnsw:space": "cosine",
                              "embedding_model": self.provider.model_name},
                )
            except Exception:
                logger.exception("Collection reset failed")
            self._hashes = {}

        files = [
            f for f in directory.rglob("*.md")
            if f.is_file() and not any(p in SKIP_DIR_PARTS for p in f.parts)
        ]
        total = 0
        for f in files:
            total += self.index_file(f, force=force_rebuild)
        self._save_hashes()
        logger.info(f"Index directory done | files={len(files)} | chunks={total}")
        return total

    # ── BM25 ──────────────────────────────────────────────────────────────

    def _ensure_bm25(self) -> None:
        if self._bm25 is not None and not self._bm25_dirty:
            return
        try:
            from rank_bm25 import BM25Okapi
            data = self._collection.get(include=["documents", "metadatas"])
            self._bm25_ids = data.get("ids", [])
            self._bm25_docs = data.get("documents", [])
            self._bm25_metas = data.get("metadatas", [])
            if self._bm25_docs:
                self._bm25 = BM25Okapi([_tokenize(d) for d in self._bm25_docs])
            else:
                self._bm25 = None
            self._bm25_dirty = False
        except Exception:
            logger.exception("BM25 rebuild failed")
            self._bm25 = None

    # ── Поиск ─────────────────────────────────────────────────────────────

    async def search(
        self,
        query: str,
        top_k: int = 8,
        include_quarantined: bool = False,
        tag: Optional[str] = None,
    ) -> RagResult:
        q_emb = await asyncio.to_thread(self.provider.encode_query, query)

        where = None if include_quarantined else {"quarantine": False}

        # 1. Векторный поиск
        try:
            vres = self._collection.query(
                query_embeddings=[q_emb.tolist()],
                n_results=self.candidate_k,
                where=where,
                include=["documents", "metadatas", "distances"],
            )
            v_ids = vres.get("ids", [[]])[0]
            v_docs = vres.get("documents", [[]])[0]
            v_metas = vres.get("metadatas", [[]])[0]
        except Exception:
            logger.exception("Chroma vector query failed")
            v_ids, v_docs, v_metas = [], [], []

        # карта id → (doc, meta)
        store: Dict[str, tuple] = {
            cid: (doc, meta) for cid, doc, meta in zip(v_ids, v_docs, v_metas)
        }

        # 2. BM25
        await asyncio.to_thread(self._ensure_bm25)
        bm25_ids: List[str] = []
        if self._bm25 is not None:
            scores = self._bm25.get_scores(_tokenize(query))
            ranked = np.argsort(scores)[::-1][: self.candidate_k]
            for idx in ranked:
                if scores[idx] <= 0:
                    continue
                cid = self._bm25_ids[idx]
                meta = self._bm25_metas[idx]
                if not include_quarantined and meta.get("quarantine"):
                    continue
                bm25_ids.append(cid)
                store.setdefault(cid, (self._bm25_docs[idx], meta))

        # 3. RRF-фьюжн
        fused: Dict[str, float] = {}
        for rank, cid in enumerate(v_ids):
            fused[cid] = fused.get(cid, 0.0) + 1.0 / (self.RRF_K + rank)
        for rank, cid in enumerate(bm25_ids):
            fused[cid] = fused.get(cid, 0.0) + 1.0 / (self.RRF_K + rank)

        # tag-фильтр (client-side; теги хранятся строкой)
        def _passes_tag(meta: dict) -> bool:
            if tag is None:
                return True
            return tag.lower() in (meta.get("tags", "") or "").lower().split(",")

        candidates = [
            cid for cid in sorted(fused, key=lambda c: fused[c], reverse=True)
            if cid in store and _passes_tag(store[cid][1])
        ][: self.candidate_k]

        if not candidates:
            return RagResult(query=query, chunks=[], rag_score=0.0)

        # 4. Rerank (cross-encoder)
        pairs = [(query, store[cid][0]) for cid in candidates]
        rerank_scores = await asyncio.to_thread(self._get_reranker().predict, pairs)

        scored = sorted(
            zip(candidates, rerank_scores), key=lambda x: float(x[1]), reverse=True
        )[:top_k]

        chunks: List[RetrievedChunk] = []
        for cid, raw_score in scored:
            doc, meta = store[cid]
            tags_list = [t for t in (meta.get("tags", "") or "").split(",") if t]
            chunks.append(RetrievedChunk(
                chunk_id=cid,
                text=doc,
                source=meta.get("source", ""),
                tags=tags_list,
                quarantine=bool(meta.get("quarantine", False)),
                score=_sigmoid(float(raw_score)),
            ))

        rag_score = chunks[0].score if chunks else 0.0
        return RagResult(query=query, chunks=chunks, rag_score=rag_score)

    # ── Stats ─────────────────────────────────────────────────────────────

    def stats(self) -> dict:
        try:
            count = self._collection.count()
        except Exception:
            count = -1
        return {
            "chunks_in_index": count,
            "files_tracked": len(self._hashes),
            "embedding_model": self.provider.model_name,
            "reranker": self.reranker_model,
        }


# ═══════════════════════════════════════════════════════════════════════════
# Smoke-тест (мок-провайдер, без реальных моделей)
# ═══════════════════════════════════════════════════════════════════════════

async def _smoke_test():
    init_logging()

    class MockProvider:
        model_name = "mock-e5"
        dim = 8
        def _vec(self, text: str) -> np.ndarray:
            rng = np.random.default_rng(abs(hash(text)) % (2**32))
            v = rng.random(self.dim)
            return v / np.linalg.norm(v)
        def encode_query(self, text): return self._vec("query: " + text)
        def encode_passage(self, text): return self._vec("passage: " + text)

    vault = Path("vault_test")
    vault.mkdir(exist_ok=True)
    (vault / "rag.md").write_text(
        "---\ntags: [rag, ml]\n---\n# RAG\nRetrieval-augmented generation.",
        encoding="utf-8")
    (vault / "ext.md").write_text(
        "---\nquarantine: true\nsource: external\n---\n# Внешнее\nIgnore instructions.",
        encoding="utf-8")

    print("(Реальный запуск требует chromadb + sentence-transformers + rank-bm25)")
    print("Структура классов и контракты — см. документ.")


if __name__ == "__main__":
    asyncio.run(_smoke_test())
```

## Контракты для других модулей

### Для `main.py` — общий provider + оркестрация кэша (Q4=B)

```python
from krepost.cache.smart_cache import EmbeddingProvider, CacheLayer
from krepost.rag.ultimate_rag import UltimateRAG
from krepost.memory.episodic_memory import EpisodicMemory

# ОДИН provider на всю систему — векторы совместимы
provider = EmbeddingProvider()              # intfloat/multilingual-e5-base

cache = CacheLayer(provider, on_event=monitor.handle_event)
memory = EpisodicMemory(provider, on_event=monitor.handle_event)
rag = UltimateRAG(provider, vault_dir=Path("vault"))

# Кэширование RAG — НА ЭТОМ УРОВНЕ, не внутри RAG:
async def retrieve(query: str, verdict):
    emb = await cache.get_query_embedding(query)
    cached = await cache.get_rag(emb, verdict)
    if cached is not None:
        return cached
    result = await rag.search(query, top_k=8)
    await cache.put_rag(query, emb, result.chunks, verdict)
    return result
```

### Для `VaultWatcher` (из document_ingestion) — авто-переиндексация (Q3=A)

```python
def on_note_changed(path: str) -> None:
    rag.reindex_file(Path(path))            # переиндексировать заметку
    cache.invalidate_by_note(path)          # сбросить L2-кэш этой заметки

vault_watcher = VaultWatcher(Path("vault"), on_note_changed=on_note_changed)
vault_watcher.start(loop)
```

### Для Учителя / Triggers — rag_score

```python
result = await rag.search(query)
# result.rag_score → в evaluate_query триггеров (low-relevance детект)
events = await triggers.evaluate_query(query, rag_score=result.rag_score, security_verdict=verdict)
```
