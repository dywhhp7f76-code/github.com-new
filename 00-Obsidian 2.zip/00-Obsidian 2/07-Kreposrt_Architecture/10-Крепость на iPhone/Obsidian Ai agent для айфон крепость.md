✅ Полная документация: Obsidian AI Agent для iPhone 17 Pro

Я сделал реалистичную и рабочую систему под текущие ограничения iOS 18/19 (iPhone 17 Pro).

Общая архитектура

Вариант A (Локальный) — максимум приватности, минимум зависимости.  
Вариант B (Гибридный) — мощнее, удобнее, но требует VPS.

  

ВАРИАНТ A: Полностью локальный (рекомендую начать с него)

Пошаговая настройка на iPhone 17 Pro

1. Установи необходимые приложения:

- Obsidian (основное)
- Pythonista (лучший вариант для скриптов) или Scriptable
- Shortcuts (встроенное)
- a-Shell (опционально, для терминала)

3. Настрой Obsidian:

- Включи iCloud Sync
- Установи плагины: Advanced URI, Dataview, Templater, QuickAdd

5. Создай структуру (сделай вручную):Obsidian/
6. ├── Inbox/
7. ├── Web/
8. ├── PDF/
9. └── 00_System/
10.     └── Prompts/
11.   
    

  

Промты для ИИ (используй в Pythonista/Scriptable)

Промт 1: Анализ текста + теги

Ты — Obsidian AI Assistant.

  

Проанализируй текст заметки и верни строго в формате YAML:

  

```yaml

title: Краткое название (3-8 слов)

tags: ["#тег1", "#тег2", "#тег3"]

category: "Личное/Работа/Обучение/Здоровье"

summary: Краткое summary (1-2 предложения)

links: ["[[Связанная заметка 1]]", "[[Связанная заметка 2]]"]

Текст заметки: {{текст}}

**Промт 2: Веб-поиск → Markdown**

  

```markdown

Преобразуй результаты поиска в чистый Markdown для Obsidian.

  

Формат:

# Заголовок

  

**Дата:** {{дата}}

**Источник:** {{ссылка}}

  

Краткое summary...

  

Ключевые факты:

- пункт 1

- пункт 2

  

Теги: #тег1 #тег2

Промт 3: Создание папочной структуры

По запросу пользователя создай структуру папок и предложи YAML frontmatter.

  

Ответь строго в формате:

  

```yaml

folders:

  - "05_Цели/2026"

  - "06_Проекты/Новый проект"

  

frontmatter:

  tags: ["#цели", "#2026"]

  status: "active"

Запрос: {{запрос}}

---

  

### Код для Pythonista / Scriptable (локальный вариант)

  

**Скрипт `obsidian_agent.py`** (в Pythonista):

  

```python

import requests

import json

  

def send_to_ai(text, prompt_type="analyze"):

    # Здесь можно использовать Grok API или Venice

    # Пока placeholder

    print("Отправлено в ИИ...")

    return "Обработано"

  

# Пример использования

text = "Текст из заметки"

result = send_to_ai(text, "analyze")

print(result)

  

ВАРИАНТ B: Гибридный (n8n + webhook) — самый мощный

Пошаговая настройка

1. Арендуй дешёвый VPS (Hetzner / DigitalOcean ~$5/мес)
2. Установи n8n (docker-compose)
3. Создай workflow:

- Webhook trigger
- AI Agent (Grok / Claude / OpenAI)
- Save to iCloud (через WebDAV или直接 в Obsidian iCloud folder)

5. В Shortcuts на iPhone:

- Get Text → POST to n8n webhook
- Получаешь ответ → Save to Files (iCloud)

  

Хочешь, я прямо сейчас дам:

1. Полный JSON workflow для n8n (гибридный вариант)
2. Готовый шорткат для iPhone (текстовое описание)
3. Лучшие промпты для Grok API

Скажи, какой вариант тебе нужнее в первую очередь (A или B), и я дам полный готовый код + инструкцию «для чайников».

Что выбираешь?