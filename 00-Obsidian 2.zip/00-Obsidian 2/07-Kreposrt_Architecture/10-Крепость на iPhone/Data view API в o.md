✅ Полный гид по Dataview API в Obsidian (2026)

Dataview API — это JavaScript-интерфейс плагина Dataview, который позволяет писать код внутри Obsidian (через Templater, DataviewJS или CustomJS) и работать с заметками как с базой данных.

1. Как включить DataviewJS

2. Убедись, что плагин Dataview установлен и включён.
3. В настройках Dataview включи “Enable DataviewJS”.

4. Основные способы использования API

Способ 1: Кодовый блок `dataviewjs`

const pages = dv.pages("#цели")

  .where(p => p.status === "active")

  .sort(p => p.priority, "desc");

  

dv.table(["Название", "Приоритет", "Статус"], 

  pages.map(p => [p.file.link, p.priority, p.status])

);

Способ 2: В Templater (самый удобный)

Создай шаблон Templater и используй:

<%*

const dv = app.plugins.plugins.dataview.api;

  

const pages = dv.pages("#проекты")

  .where(p => !p.completed)

  .sort(p => p.due);

  

tR += dv.markdownTable(["Задача", "Срок"], 

  pages.map(p => [p.file.link, p.due])

);

%>

3. Основные методы Dataview API

|   |   |   |
|---|---|---|
|Метод|Описание|Пример|
|dv.pages()|Получить все заметки|dv.pages("#тег")|
|dv.page()|Получить одну заметку|dv.page("Путь/Заметка")|
|.where()|Фильтрация|.where(p => p.status === "active")|
|.sort()|Сортировка|.sort(p => p.priority)|
|.limit()|Ограничить количество|.limit(10)|
|dv.table()|Вывести таблицу|dv.table(headers, rows)|
|dv.list()|Вывести список|dv.list(items)|
|dv.paragraph()|Вывести текст|dv.paragraph("Текст")|
|dv.taskList()|Вывести задачи|dv.taskList(tasks)|

4. Полезные примеры для «Крепости»

Ежедневный обзор

const today = dv.date("today");

const tasks = dv.pages()

  .file.tasks

  .where(t => !t.completed && t.due && t.due <= today.plus({ days: 7 }));

  

dv.taskList(tasks);

Анализ целей

const goals = dv.pages("#цели")

  .sort(p => p.progress, "desc");

  

dv.table(["Цель", "Прогресс", "Срок"], 

  goals.map(g => [g.file.link, g.progress + "%", g.deadline])

);

5. Рекомендация для тебя

Для твоей системы «Крепость» на iPhone + будущем Mac я рекомендую использовать Dataview + Templater.

Хочешь, я прямо сейчас дам тебе готовый набор из 8–10 самых полезных DataviewJS-скриптов специально под структуру «Крепости» (цели, ежедневки, проекты, рефлексия, теги и т.д.)?

Напиши «Давай» — и я пришлю полный пакет.