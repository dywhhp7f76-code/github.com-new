✅ Полный обзор Obsidian API (актуально на май 2026)

1. Что такое Obsidian API

Obsidian предоставляет два основных уровня API:

- Plugin API (TypeScript) — для разработки полноценных плагинов (только Desktop).
- URI API (Obsidian URI + Advanced URI plugin) — основной способ автоматизации на iPhone и Mac.

2. Obsidian URI (самое важное для iPhone)

Это основной способ взаимодействия с Obsidian с iPhone.

Базовый формат:

obsidian://open?vault=VaultName&file=Folder%2FNote.md

Примеры:

- Открыть заметку: obsidian://open?vault=МойВаулт&file=05_Цели%2F2026.md
- Создать новую заметку: obsidian://new?vault=МойВаулт&name=Новая%20заметка&content=Текст%20заметки
- Выполнить команду (через Advanced URI): obsidian://advanced-uri?vault=МойВаулт&commandid=quickadd%3AinsertTemplate

3. Advanced URI Plugin (ключевой плагин)

Это расширение Obsidian URI, которое даёт огромные возможности.

Основные команды:

- obsidian://advanced-uri?vault=...&commandid=... — выполнить любую команду
- obsidian://advanced-uri?vault=...&filepath=...&mode=append — добавить текст в файл
- obsidian://advanced-uri?vault=...&search=текст — поиск

Рекомендуемые настройки (из твоего скриншота):

- Open file on write — включить
- Include vault name/ID parameter — включить
- Allow executing arbitrary code via eval — выключить (опасно)

4. Dataview API (очень полезно)

Dataview позволяет делать SQL-подобные запросы к твоим заметкам.

Пример в заметке:

TABLE file.ctime AS "Дата", status AS "Статус"

FROM "#цели"

WHERE status = "active"

SORT priority DESC

DataviewJS (JavaScript API):

const pages = dv.pages("#проекты")

  .where(p => !p.completed);

  

dv.table(["Задача", "Срок"], pages.map(p => [p.file.link, p.due]));

5. Рекомендация для твоей «Крепости»

Для iPhone сейчас лучший стек:

- Obsidian + Advanced URI + Dataview + Templater
- Shortcuts для отправки заметок мне (Grok)
- Я (Grok) выступаю как внешний ИИ-аналитик

Когда будет Mac — добавим локальный Ollama + LlamaIndex.

Хочешь, я прямо сейчас дам тебе:

- Готовый набор Dataview-запросов для твоей структуры
- Шаблоны Templater
- Инструкцию по созданию шортката для отправки заметок мне

Скажи, что нужно в первую очередь.