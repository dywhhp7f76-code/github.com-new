---
tags:
  - крепость
  - код
  - tool-chains
  - агенты
date: 2026-06-15
status: готово
---
"""
krepost/agents/autonomous_triggers.py
Autonomous Triggers v2.1 — под архитектуру «Крепость».

Event-driven: SCHEDULE-триггеры — через background loop, остальные
через явный вызов из app.py (evaluate_query) и подписку на события.

Дефолтный триггер один: high_error_rate (5 ошибок за 60 сек → YELLOW push).

Изменения v2.0 → v2.1 (свод 4 аудитов + прогон):
  P0-1  RACE в deque: record_error (append из thread-pool ingestion) +
        _errors_in_window (sum-итерация из event loop) → "deque mutated during
        iteration" (прогон: 401 RuntimeError). Защищено threading.Lock.
  P1-1  Блокирующий SQLite в async _fire: save_state/log_fire синхронные внутри
        event loop → на массовом ingest держат loop 10-50мс. Теперь to_thread.
  P1-2  WAL не включался в TriggerHistoryDB (был только в security). Добавлен
        PRAGMA journal_mode=WAL + synchronous=NORMAL при каждом connect.
  P2-1  None в record_error: message[:80] падал на None. Теперь (message or "").
  P2-2  _errors_in_window: popleft хвоста вместо sum (амортизир. O(1)), под тем
        же локом, что P0-1.
  P2-3  enable() пересобирает _compiled_patterns, если их нет (защита от мутации).
"""

from __future__ import annotations

import asyncio
import json
import re
import sqlite3
import threading
import time
import uuid
from collections import deque
from contextlib import contextmanager
from dataclasses import dataclass, field
from enum import Enum
from pathlib import Path
from typing import (
    Annotated, Any, Awaitable, Callable, Dict, List, Literal,
    Optional, Union,
)

from loguru import logger
from pydantic import BaseModel, Field


def init_logging(log_dir: Path = Path("data/logs")) -> None:
    log_dir.mkdir(parents=True, exist_ok=True)
    logger.add(log_dir / "triggers.log", rotation="10 MB", level="INFO", enqueue=True)


class SecurityVerdict(str, Enum):
    GREEN = "green"
    YELLOW = "yellow"
    RED = "red"


class TriggerType(str, Enum):
    SCHEDULE = "schedule"
    KEYWORD = "keyword"
    THRESHOLD = "threshold"
    ERROR_RATE = "error_rate"


class TriggerStatus(str, Enum):
    ACTIVE = "active"
    DISABLED = "disabled"


class ScheduleCondition(BaseModel):
    type: Literal[TriggerType.SCHEDULE] = TriggerType.SCHEDULE
    interval_sec: float = Field(gt=0)


class KeywordCondition(BaseModel):
    type: Literal[TriggerType.KEYWORD] = TriggerType.KEYWORD
    patterns: List[str]


class ThresholdCondition(BaseModel):
    type: Literal[TriggerType.THRESHOLD] = TriggerType.THRESHOLD
    metric: str
    op: Literal["gt", "lt", "ge", "le", "eq"] = "lt"
    value: float


class ErrorRateCondition(BaseModel):
    type: Literal[TriggerType.ERROR_RATE] = TriggerType.ERROR_RATE
    max_errors: int = Field(gt=0)
    window_sec: float = Field(gt=0)


Condition = Annotated[
    Union[ScheduleCondition, KeywordCondition, ThresholdCondition, ErrorRateCondition],
    Field(discriminator="type"),
]


class Trigger(BaseModel):
    id: str = Field(default_factory=lambda: str(uuid.uuid4()))
    name: str
    condition: Condition
    action: str
    cooldown_sec: float = Field(default=60.0, ge=0)
    risk_level: int = Field(default=0, ge=0, le=2)
    status: TriggerStatus = TriggerStatus.ACTIVE


class ActionResult(BaseModel):
    success: bool
    message: str = ""
    payload: Dict[str, Any] = Field(default_factory=dict)


ActionFn = Callable[[Dict], Union[ActionResult, Awaitable[ActionResult]]]


class TriggerEventLevel(str, Enum):
    GREEN = "green"
    YELLOW = "yellow"
    RED = "red"


class TriggerEventType(str, Enum):
    FIRED = "fired"
    ACTION_FAILED = "action_failed"
    ACTION_MISSING = "action_missing"


@dataclass
class TriggerEvent:
    level: TriggerEventLevel
    type: TriggerEventType
    trigger_id: str
    trigger_name: str
    action: str
    action_result: Optional[ActionResult]
    payload: dict = field(default_factory=dict)
    timestamp: float = field(default_factory=time.time)


def emit_event(event: TriggerEvent, callback: Optional[Callable[[TriggerEvent], None]]) -> None:
    msg = (f"[{event.level.value.upper()}] {event.type.value} | "
           f"{event.trigger_name} | action={event.action}")
    if event.level == TriggerEventLevel.GREEN:
        logger.info(msg)
    elif event.level == TriggerEventLevel.YELLOW:
        logger.warning(msg)
    else:
        logger.error(msg)
    if callback is not None:
        try:
            callback(event)
        except Exception:
            logger.exception("on_event callback failed")


class TriggerHistoryDB:
    """SQLite-персистентность. Общий файл с Router'ом, отдельные таблицы."""

    SCHEMA = """
    CREATE TABLE IF NOT EXISTS trigger_state (
        trigger_id  TEXT PRIMARY KEY,
        name        TEXT NOT NULL,
        last_fired  REAL NOT NULL DEFAULT 0,
        fire_count  INTEGER NOT NULL DEFAULT 0
    );
    CREATE TABLE IF NOT EXISTS trigger_fires (
        id              INTEGER PRIMARY KEY AUTOINCREMENT,
        trigger_id      TEXT NOT NULL,
        trigger_name    TEXT NOT NULL,
        fired_at        REAL NOT NULL,
        action          TEXT NOT NULL,
        success         INTEGER NOT NULL,
        action_message  TEXT,
        action_payload  TEXT,
        context_preview TEXT
    );
    CREATE INDEX IF NOT EXISTS idx_fires_time ON trigger_fires(fired_at);
    CREATE INDEX IF NOT EXISTS idx_fires_trigger ON trigger_fires(trigger_id);
    """

    def __init__(self, db_path: Path = Path("data/krepost_analytics.db")):
        db_path.parent.mkdir(parents=True, exist_ok=True)
        self.db_path = db_path
        with self._connect() as conn:
            conn.executescript(self.SCHEMA)

    @contextmanager
    def _connect(self):
        conn = sqlite3.connect(self.db_path, timeout=5.0)
        try:
            # P1-2: WAL не включается сам — форсируем при каждом соединении
            conn.execute("PRAGMA journal_mode=WAL")
            conn.execute("PRAGMA synchronous=NORMAL")
            yield conn
            conn.commit()
        finally:
            conn.close()

    def load_state(self, trigger_id: str) -> Optional[dict]:
        try:
            with self._connect() as conn:
                row = conn.execute(
                    "SELECT last_fired, fire_count FROM trigger_state WHERE trigger_id = ?",
                    (trigger_id,)).fetchone()
                return {"last_fired": row[0], "fire_count": row[1]} if row else None
        except sqlite3.Error:
            logger.exception("trigger load_state failed")
            return None

    def save_state(self, trigger_id: str, name: str, last_fired: float, fire_count: int) -> None:
        try:
            with self._connect() as conn:
                conn.execute(
                    """INSERT INTO trigger_state(trigger_id, name, last_fired, fire_count)
                       VALUES (?, ?, ?, ?)
                       ON CONFLICT(trigger_id) DO UPDATE SET
                           name=excluded.name, last_fired=excluded.last_fired,
                           fire_count=excluded.fire_count""",
                    (trigger_id, name, last_fired, fire_count))
        except sqlite3.Error:
            logger.exception("trigger save_state failed")

    def log_fire(self, trigger_id: str, trigger_name: str, fired_at: float,
                 action: str, result: Optional[ActionResult], context: dict) -> None:
        try:
            ctx_preview = json.dumps(
                {k: str(v)[:80] for k, v in context.items() if not k.startswith("_")},
                ensure_ascii=False)
            with self._connect() as conn:
                conn.execute(
                    """INSERT INTO trigger_fires
                       (trigger_id, trigger_name, fired_at, action, success,
                        action_message, action_payload, context_preview)
                       VALUES (?, ?, ?, ?, ?, ?, ?, ?)""",
                    (trigger_id, trigger_name, fired_at, action,
                     int(result.success) if result else 0,
                     result.message if result else "action_missing",
                     json.dumps(result.payload, ensure_ascii=False) if result else None,
                     ctx_preview))
        except sqlite3.Error:
            logger.exception("trigger log_fire failed")


class AutonomousTriggers:
    """Event-driven движок триггеров с persistence и Telegram-алертами."""

    DEFAULT_LOOP_INTERVAL_SEC = 10.0
    DEFAULT_ERROR_LOG_SIZE = 500

    def __init__(self, db: Optional[TriggerHistoryDB] = None,
                 on_event: Optional[Callable[[TriggerEvent], None]] = None,
                 loop_interval_sec: float = DEFAULT_LOOP_INTERVAL_SEC):
        self.db = db or TriggerHistoryDB()
        self.on_event = on_event
        self.loop_interval_sec = loop_interval_sec

        self.triggers: Dict[str, Trigger] = {}
        self.actions: Dict[str, ActionFn] = {}

        self._last_fired: Dict[str, float] = {}
        self._fire_counts: Dict[str, int] = {}
        self._error_timestamps: deque = deque(maxlen=self.DEFAULT_ERROR_LOG_SIZE)
        # P0-1: deque трогается из thread-pool (record_error) и event loop
        # (_errors_in_window) → нужен threading.Lock, не asyncio.
        self._error_lock = threading.Lock()
        self._compiled_patterns: Dict[str, List[re.Pattern]] = {}

        self._eval_lock = asyncio.Lock()
        self._running = False
        self._loop_task: Optional[asyncio.Task] = None

        self._register_defaults()

    def _register_defaults(self) -> None:
        def send_alert(context: Dict) -> ActionResult:
            return ActionResult(success=True, message="alert dispatched via on_event",
                                payload={"error_count_window": context.get("error_count_window", 0)})
        self.register_action("send_alert", send_alert)
        self.register(Trigger(
            name="high_error_rate",
            condition=ErrorRateCondition(max_errors=5, window_sec=60),
            action="send_alert", cooldown_sec=300, risk_level=1))

    def register(self, trigger: Trigger) -> str:
        state = self.db.load_state(trigger.id)
        if state is not None:
            self._last_fired[trigger.id] = state["last_fired"]
            self._fire_counts[trigger.id] = state["fire_count"]
        else:
            initial = time.time() if isinstance(trigger.condition, ScheduleCondition) else 0.0
            self._last_fired[trigger.id] = initial
            self._fire_counts[trigger.id] = 0
            self.db.save_state(trigger.id, trigger.name, initial, 0)
        if isinstance(trigger.condition, KeywordCondition):
            self._compiled_patterns[trigger.id] = [
                re.compile(p, re.IGNORECASE) for p in trigger.condition.patterns]
        self.triggers[trigger.id] = trigger
        logger.info(f"Trigger registered | {trigger.name} | type={trigger.condition.type.value}")
        return trigger.id

    def register_action(self, name: str, fn: ActionFn) -> None:
        self.actions[name] = fn
        logger.info(f"Action registered: {name}")

    def disable(self, trigger_id: str) -> None:
        if trigger_id in self.triggers:
            self.triggers[trigger_id].status = TriggerStatus.DISABLED

    def enable(self, trigger_id: str) -> None:
        if trigger_id in self.triggers:
            t = self.triggers[trigger_id]
            t.status = TriggerStatus.ACTIVE
            # P2-3: восстановить паттерны, если их нет (после внешней мутации)
            if isinstance(t.condition, KeywordCondition) and trigger_id not in self._compiled_patterns:
                self._compiled_patterns[trigger_id] = [
                    re.compile(p, re.IGNORECASE) for p in t.condition.patterns]

    def record_error(self, source: str = "", message: str = "") -> None:
        """Вызывать при ошибках из Router/Cache/Ingestion/RAG (часто из потоков)."""
        with self._error_lock:                       # P0-1
            self._error_timestamps.append(time.time())
        # P2-1: source/message могут прийти None из чужих обработчиков
        logger.debug(f"Error recorded | source={source or 'unknown'} | {(message or '')[:80]}")

    def _errors_in_window(self, window_sec: float) -> int:
        now = time.time()
        cutoff = now - window_sec
        with self._error_lock:                       # P0-1 + P2-2
            # popleft устаревших — амортизированный O(1) вместо O(n) sum
            while self._error_timestamps and self._error_timestamps[0] < cutoff:
                self._error_timestamps.popleft()
            return len(self._error_timestamps)

    async def evaluate(self, context: Dict) -> List[TriggerEvent]:
        async with self._eval_lock:
            fired: List[TriggerEvent] = []
            now = time.time()
            for trigger in self.triggers.values():
                if trigger.status != TriggerStatus.ACTIVE:
                    continue
                if now - self._last_fired.get(trigger.id, 0.0) < trigger.cooldown_sec:
                    continue
                if not self._check_condition(trigger, context):
                    continue
                fired.append(await self._fire(trigger, context))
            return fired

    async def evaluate_query(self, query: str, rag_score: float = 1.0,
                             security_verdict: SecurityVerdict = SecurityVerdict.GREEN
                             ) -> List[TriggerEvent]:
        context: Dict[str, Any] = {
            "rag_score": rag_score,
            "error_count_window": self._errors_in_window(60),
        }
        # KEYWORD только при GREEN; query пробрасываем только если непустой
        if security_verdict == SecurityVerdict.GREEN and query:
            context["query"] = query
        return await self.evaluate(context)

    async def evaluate_schedule(self) -> List[TriggerEvent]:
        return await self.evaluate({"_schedule_check": True})

    def _check_condition(self, trigger: Trigger, context: Dict) -> bool:
        cond = trigger.condition
        if isinstance(cond, ScheduleCondition):
            return time.time() - self._last_fired.get(trigger.id, 0.0) >= cond.interval_sec
        if isinstance(cond, KeywordCondition):
            query = context.get("query")
            if not query:
                return False
            patterns = self._compiled_patterns.get(trigger.id, [])
            return any(p.search(query) for p in patterns)
        if isinstance(cond, ThresholdCondition):
            metric = context.get(cond.metric)
            if metric is None:
                return False
            try:
                metric = float(metric)
            except (TypeError, ValueError):
                return False
            ops = {"gt": metric > cond.value, "lt": metric < cond.value,
                   "ge": metric >= cond.value, "le": metric <= cond.value,
                   "eq": metric == cond.value}
            return ops.get(cond.op, False)
        if isinstance(cond, ErrorRateCondition):
            return self._errors_in_window(cond.window_sec) >= cond.max_errors
        return False

    async def _fire(self, trigger: Trigger, context: Dict) -> TriggerEvent:
        now = time.time()
        self._last_fired[trigger.id] = now
        self._fire_counts[trigger.id] = self._fire_counts.get(trigger.id, 0) + 1

        result: Optional[ActionResult] = None
        if trigger.action not in self.actions:
            event_level = TriggerEventLevel.YELLOW
            event_type = TriggerEventType.ACTION_MISSING
            logger.warning(f"Action not registered: {trigger.action}")
        else:
            fn = self.actions[trigger.action]
            try:
                raw = fn(context)
                if asyncio.iscoroutine(raw):
                    raw = await raw
                result = raw if isinstance(raw, ActionResult) else ActionResult(
                    success=True, message=str(raw if raw is not None else "ok"))
                event_type = TriggerEventType.FIRED
                event_level = self._risk_to_level(trigger.risk_level)
            except Exception as e:
                logger.exception(f"Action failed | {trigger.action}")
                result = ActionResult(success=False, message=f"exception: {e}")
                event_level = TriggerEventLevel.RED
                event_type = TriggerEventType.ACTION_FAILED

        # P1-1: запись в SQLite — блокирующая, выносим из event loop
        await asyncio.to_thread(self.db.save_state, trigger.id, trigger.name, now,
                                self._fire_counts[trigger.id])
        await asyncio.to_thread(self.db.log_fire, trigger.id, trigger.name, now,
                                trigger.action, result, context)

        event = TriggerEvent(level=event_level, type=event_type, trigger_id=trigger.id,
                             trigger_name=trigger.name, action=trigger.action,
                             action_result=result,
                             payload={"fire_count": self._fire_counts[trigger.id]})
        emit_event(event, self.on_event)
        return event

    @staticmethod
    def _risk_to_level(risk: int) -> TriggerEventLevel:
        if risk == 0:
            return TriggerEventLevel.GREEN
        if risk == 1:
            return TriggerEventLevel.YELLOW
        return TriggerEventLevel.RED

    async def start(self) -> None:
        if self._running:
            return
        self._running = True
        self._loop_task = asyncio.create_task(self._schedule_loop())
        logger.info("AutonomousTriggers started")

    async def stop(self) -> None:
        self._running = False
        if self._loop_task is not None:
            self._loop_task.cancel()
            try:
                await self._loop_task
            except asyncio.CancelledError:
                pass
            self._loop_task = None
        logger.info("AutonomousTriggers stopped")

    async def _schedule_loop(self) -> None:
        try:
            while self._running:
                try:
                    await self.evaluate_schedule()
                except Exception:
                    logger.exception("evaluate_schedule failed in loop")
                await asyncio.sleep(self.loop_interval_sec)
        except asyncio.CancelledError:
            raise

    def stats(self) -> Dict:
        return {t.name: {"id": t.id, "type": t.condition.type.value,
                         "fire_count": self._fire_counts.get(t.id, 0),
                         "last_fired": self._last_fired.get(t.id, 0.0),
                         "status": t.status.value, "risk_level": t.risk_level}
                for t in self.triggers.values()}
