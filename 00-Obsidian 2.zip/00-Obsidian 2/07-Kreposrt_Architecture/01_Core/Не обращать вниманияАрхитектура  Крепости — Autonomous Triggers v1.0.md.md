# уже есть krepost/agents/
# → krepost/agents/autonomous_triggers.py


"""
krepost/agents/autonomous_triggers.py
Autonomous Triggers v2.0
"""
import asyncio
import json
import time
import uuid
from enum import Enum
from pathlib import Path
from typing import Callable, Dict, List, Optional

from loguru import logger
from pydantic import BaseModel, Field

# ─── Логирование ──────────────────────────────────────────────────────────────
LOG_DIR = Path("data/logs")
LOG_DIR.mkdir(parents=True, exist_ok=True)
logger.remove()
logger.add(LOG_DIR / "triggers.log", rotation="10 MB", level="INFO", enqueue=True)

PERSIST_PATH = Path("data/triggers_state.json")


# ─── Типы ─────────────────────────────────────────────────────────────────────

class TriggerType(str, Enum):
    SCHEDULE   = "schedule"
    THRESHOLD  = "threshold"
    KEYWORD    = "keyword"
    RAG_SCORE  = "rag_score"
    ERROR_RATE = "error_rate"


class TriggerStatus(str, Enum):
    ACTIVE   = "active"
    DISABLED = "disabled"


# ─── Модели ───────────────────────────────────────────────────────────────────

class Trigger(BaseModel):
    id: str = Field(default_factory=lambda: str(uuid.uuid4()))
    name: str
    type: TriggerType
    status: TriggerStatus = TriggerStatus.ACTIVE
    condition: Dict
    action: str
    cooldown: float = 60.0
    last_fired: float = 0.0
    fire_count: int = 0


class TriggerEvent(BaseModel):
    trigger_id: str
    trigger_name: str
    fired_at: float = Field(default_factory=time.time)
    context: Dict = Field(default_factory=dict)
    action_result: str = ""


# ─── Engine ───────────────────────────────────────────────────────────────────

class AutonomousTriggers:

    MAX_HISTORY = 500  # лимит истории

    def __init__(self):
        self.triggers: Dict[str, Trigger] = {}
        self.actions: Dict[str, Callable] = {}
        self.history: List[TriggerEvent] = []
        self._running = False
        self._schedule_task: Optional[asyncio.Task] = None
        self._lock = asyncio.Lock()  # Fix 3: защита от race condition
        self._default_ids: Dict[str, str] = {}  # Fix 5: ID дефолтных триггеров

        self._load_state()
        self._register_defaults()

    # ── Persistence ───────────────────────────────────────────────────────────

    def _load_state(self):
        """Fix 7: загрузка состояния при рестарте"""
        if not PERSIST_PATH.exists():
            return
        try:
            data = json.loads(PERSIST_PATH.read_text(encoding="utf-8"))
            for t in data.get("triggers", []):
                trigger = Trigger(**t)
                self.triggers[trigger.id] = trigger
            logger.info(f"Loaded {len(self.triggers)} triggers from state")
        except Exception as e:
            logger.warning(f"Failed to load state: {e}")

    def _save_state(self):
        """Сохранение состояния триггеров"""
        PERSIST_PATH.parent.mkdir(parents=True, exist_ok=True)
        data = {
            "triggers": [t.model_dump() for t in self.triggers.values()]
        }
        PERSIST_PATH.write_text(
            json.dumps(data, ensure_ascii=False, indent=2),
            encoding="utf-8"
        )

    # ── Registration ──────────────────────────────────────────────────────────

    def register(self, trigger: Trigger) -> str:
        self.triggers[trigger.id] = trigger
        self._save_state()
        logger.info(f"Trigger registered | {trigger.name} | type={trigger.type}")
        return trigger.id

    def register_action(self, name: str, fn: Callable):
        self.actions[name] = fn
        logger.info(f"Action registered: {name}")

    def disable(self, trigger_id: str):
        if trigger_id in self.triggers:
            self.triggers[trigger_id].status = TriggerStatus.DISABLED
            self._save_state()
            logger.info(f"Trigger disabled: {trigger_id[:8]}")

    def enable(self, trigger_id: str):
        if trigger_id in self.triggers:
            self.triggers[trigger_id].status = TriggerStatus.ACTIVE
            self._save_state()

    # ── Default Triggers ──────────────────────────────────────────────────────

    def _register_defaults(self):
        # Не создаём дубли при загрузке из state
        existing_names = {t.name for t in self.triggers.values()}

        defaults = [
            Trigger(
                name="low_rag_score",
                type=TriggerType.RAG_SCORE,
                condition={"threshold": 0.4},
                action="rebuild_index",
                cooldown=600,
            ),
            Trigger(
                name="high_error_rate",
                type=TriggerType.ERROR_RATE,
                condition={"max_errors": 5, "window": 60},
                action="send_alert",
                cooldown=300,
            ),
            Trigger(
                name="urgent_keyword",
                type=TriggerType.KEYWORD,
                condition={"keywords": ["срочно", "urgent", "критично", "critical"]},
                action="switch_to_fast_mode",
                cooldown=30,
            ),
            Trigger(
                name="session_summary",
                type=TriggerType.SCHEDULE,
                condition={"interval": 1800},
                action="summarize_session",
                cooldown=1800,
            ),
        ]

        for trigger in defaults:
            if trigger.name not in existing_names:
                tid = self.register(trigger)
                self._default_ids[trigger.name] = tid  # Fix 5

    # ── Condition Check ───────────────────────────────────────────────────────

    # Fix 1: sync вместо async — await нет нигде
    def _check_condition(self, trigger: Trigger, context: Dict) -> bool:

        if trigger.type == TriggerType.RAG_SCORE:
            score = context.get("rag_score", 1.0)
            return score < trigger.condition.get("threshold", 0.4)

        elif trigger.type == TriggerType.KEYWORD:
            query = context.get("query", "").lower()
            keywords = trigger.condition.get("keywords", [])
            return any(kw in query for kw in keywords)

        elif trigger.type == TriggerType.ERROR_RATE:
            # Fix 2: используем window — считаем ошибки за N секунд
            max_errors = trigger.condition.get("max_errors", 5)
            window = trigger.condition.get("window", 60)
            error_history = context.get("error_history", [])
            now = time.time()
            recent = [e for e in error_history if now - e < window]
            return len(recent) >= max_errors

        elif trigger.type == TriggerType.SCHEDULE:
            interval = trigger.condition.get("interval", 3600)
            return time.time() - trigger.last_fired >= interval

        elif trigger.type == TriggerType.THRESHOLD:
            metric = context.get(trigger.condition.get("metric", ""), 0)
            threshold = trigger.condition.get("value", 0)
            op = trigger.condition.get("op", "gt")
            if op == "gt":
                return metric > threshold
            elif op == "lt":
                return metric < threshold
            return metric == threshold

        return False

    # ── Fire ──────────────────────────────────────────────────────────────────

    async def _fire(self, trigger: Trigger, context: Dict) -> TriggerEvent:
        # Fix 3: Lock — атомарное обновление состояния
        async with self._lock:
            trigger.last_fired = time.time()
            trigger.fire_count += 1

        action_result = ""

        if trigger.action in self.actions:
            try:
                fn = self.actions[trigger.action]
                if asyncio.iscoroutinefunction(fn):
                    action_result = await fn(context)
                else:
                    action_result = fn(context)
                action_result = str(action_result or "ok")
            except Exception as e:
                action_result = f"ERROR: {e}"
                logger.error(f"Action failed | {trigger.action} | {e}")
        else:
            action_result = f"Action '{trigger.action}' not registered"
            logger.warning(action_result)

        event = TriggerEvent(
            trigger_id=trigger.id,
            trigger_name=trigger.name,
            context={k: v for k, v in context.items() if k != "error_history"},
            action_result=action_result,
        )

        # Fix 4: лимит истории
        self.history.append(event)
        if len(self.history) > self.MAX_HISTORY:
            self.history = self.history[-self.MAX_HISTORY:]

        self._save_state()

        logger.info(
            f"Trigger FIRED | {trigger.name} | "
            f"action={trigger.action} | result={action_result[:50]}"
        )
        return event

    # ── Evaluate ──────────────────────────────────────────────────────────────

    async def evaluate(self, context: Dict) -> List[TriggerEvent]:
        fired_events = []

        for trigger in self.triggers.values():
            if trigger.status != TriggerStatus.ACTIVE:
                continue
            if time.time() - trigger.last_fired < trigger.cooldown:
                continue
            if self._check_condition(trigger, context):  # Fix 1: sync вызов
                event = await self._fire(trigger, context)
                fired_events.append(event)

        return fired_events

    # ── Background loop ───────────────────────────────────────────────────────

    async def start(self, interval: float = 10.0):
        self._running = True
        # Fix 4: сохраняем task
        self._schedule_task = asyncio.current_task()
        logger.info("Autonomous triggers started")

        while self._running:
            await asyncio.sleep(interval)
            await self.evaluate(context={"timestamp": time.time()})

    def stop(self):
        self._running = False
        if self._schedule_task:
            self._schedule_task.cancel()
        logger.info("Autonomous triggers stopped")

    # ── Utils ─────────────────────────────────────────────────────────────────

    def get_history(self, last_n: int = 20) -> List[TriggerEvent]:
        return self.history[-last_n:]

    def stats(self) -> Dict:
        return {
            t.name: {
                "fire_count": t.fire_count,
                "last_fired": t.last_fired,
                "status": t.status.value,
                "id": t.id[:8],
            }
            for t in self.triggers.values()
        }


# ─── Entry point ──────────────────────────────────────────────────────────────

async def main():
    triggers = AutonomousTriggers()

    async def rebuild_index(ctx):
        print("🔄 Rebuilding RAG index...")
        return "index_rebuilt"

    def send_alert(ctx):
        print(f"🚨 Alert!")
        return "alert_sent"

    def switch_to_fast_mode(ctx):
        print("⚡ Fast mode ON")
        return "mode_switched"

    triggers.register_action("rebuild_index", rebuild_index)
    triggers.register_action("send_alert", send_alert)
    triggers.register_action("switch_to_fast_mode", switch_to_fast_mode)

    # error_history — список timestamp'ов ошибок
    now = time.time()
    events = await triggers.evaluate(context={
        "rag_score": 0.2,
        "query": "срочно помоги",
        "error_history": [now - 10, now - 20, now - 30, now - 40, now - 50],
    })

    print(f"\nFired: {len(events)}")
    for e in events:
        print(f"  → {e.trigger_name}: {e.action_result}")

    print("\nStats:", triggers.stats())


if __name__ == "__main__":
    asyncio.run(main())