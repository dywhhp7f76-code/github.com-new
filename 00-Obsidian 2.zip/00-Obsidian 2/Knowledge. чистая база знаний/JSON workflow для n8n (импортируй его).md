
Вот готовый JSON workflow для n8n (импортируй его):

{
  "nodes": [
    {
      "parameters": {
        "httpMethod": "POST",
        "path": "venice-to-obsidian",
        "options": {}
      },
      "name": "Webhook",
      "type": "n8n-nodes-base.webhook",
      "typeVersion": 1,
      "position": [240, 300]
    },
    {
      "parameters": {
        "authentication": "headerAuth",
        "requestMethod": "POST",
        "url": "https://api.venice.ai/api/v1/chat/completions",
        "jsonParameters": true,
        "options": {},
        "headerParametersJson": "{\n  \"Content-Type\": \"application/json\"\n}",
        "bodyParametersJson": "{\n  \"model\": \"venice-uncensored\",\n  \"messages\": [\n    {\n      \"role\": \"system\",\n      \"content\": \"Ты — Raw Data Exporter. После ответа добавляй в конце блок с --- title, tags, date ---\"\n    },\n    {\n      \"role\": \"user\",\n      \"content\": \"{{ $json.body.prompt }}\"\n    }\n  ]\n}"
      },
      "name": "Venice API",
      "type": "n8n-nodes-base.httpRequest",
      "typeVersion": 2,
      "position": [460, 300]
    },
    {
      "parameters": {
        "functionCode": "const content = items[0].json.choices[0].message.content;\nconst title = content.match(/title: (.*)/)?.[1] || 'untitled';\nconst fileName = title.toLowerCase().replace(/[^a-z0-9]/g, '-') + '.md';\n\nreturn [{\n  json: {},\n  binary: {\n    data: {\n      data: Buffer.from(content).toString('base64'),\n      mimeType: 'text/markdown',\n      fileName: fileName\n    }\n  }\n}];"
      },
      "name": "Prepare MD File",
      "type": "n8n-nodes-base.function",
      "typeVersion": 1,
      "position": [680, 300]
    },
    {
      "parameters": {
        "operation": "commit",
        "repository": "obsidian-vault",
        "filePath": "{{ $json.binary.data.fileName }}",
        "binaryPropertyName": "data"
      },
      "name": "Git Commit & Push",
      "type": "n8n-nodes-base.git",
      "typeVersion": 1,
      "position": [900, 300]
    }
  ],
  "connections": {
    "Webhook": {
      "main": [
        [
          {
            "node": "Venice API",
            "type": "main",
            "index": 0
          }
        ]
      ]
    },
    "Venice API": {
      "main": [
        [
          {
            "node": "Prepare MD File",
            "type": "main",
            "index": 0
          }
        ]
      ]
    },
    "Prepare MD File": {
      "main": [
        [
          {
            "node": "Git Commit & Push",
            "type": "main",
            "index": 0
          }
        ]
      ]
    }
  }
}



Как использовать:

1.  В n8n нажми Import → вставь этот JSON.

2.  Настрой Header Auth с ключом Venice.

3.  В Obsidian Git настрой репозиторий.

4.  Отправляй POST-запросы на webhook с параметром prompt.