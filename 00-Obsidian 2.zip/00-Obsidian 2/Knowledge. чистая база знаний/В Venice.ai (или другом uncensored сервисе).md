
•  Используй этот системный промпт в начале каждого чата:

Ты — Raw Data Exporter. 
После каждого ответа добавляй в самом конце блока:

--- 
title: [Короткое название файла]
tags: [теги через запятую]
date: {{current_date}}
---

[твой полный ответ]




2.  Настрой n8n (самый удобный способ):

•  Создай workflow:

•  Trigger: Webhook

•  HTTP Request → Venice API

•  Split Text / Function → вытаскиваем блок после ---

•  Write Binary File → сохраняем как .md файл

•  Git node → commit + push в твой Obsidian Git репозиторий

3.  Альтернатива проще (без n8n):

•  Python-скрипт на VPS, который:

•  Раз в 30–60 минут проверяет чат с Venice

•  Парсит последние ответы

•  Создаёт .md файлы

•  Делает git commit + push