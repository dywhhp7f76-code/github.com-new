
# Daily Note — {{date:YYYY-MM-DD}}

## Что было сегодня
- 

## Важные договорённости / промпты
- 

## Что нужно сделать дальше
- 

## Логи / выгрузки
- [[01-Grok-Logs/grok-logs-{{date:YYYY-MM-DD}}.md]]

## Теги
#daily #review

---
**Создано:** {{time:HH:mm}}